import os
from qgis.core import (
    QgsVectorLayer,
    QgsFeatureRequest,
    QgsExpression,
    QgsVectorFileWriter
)
from PyQt5.QtWidgets import QFileDialog
 
def load_shapefile(file_path):
    """
    Load a shapefile into a QgsVectorLayer.
    Args:
        file_path (str): The path to the shapefile.
    Returns:
        QgsVectorLayer: The loaded vector layer, or None if loading failed.
    """
    layer = QgsVectorLayer(file_path, os.path.basename(file_path), "ogr")
    if not layer.isValid():
        print(f"Failed to load layer: {file_path}")
    return layer
 
def select_and_export(task):
    """
    Select features from a layer based on an expression and export them to a new shapefile.
    Args:
        task (dict): A dictionary containing the layer, expression, and output path.
    """
    layer = task["layer"]
    expression = task["expression"]
    output_path = task["output"]
 
    selection = layer.getFeatures(QgsFeatureRequest(QgsExpression(expression)))
    selected_ids = [s.id() for s in selection]
    if selected_ids:
        layer.selectByIds(selected_ids)
        QgsVectorFileWriter.writeAsVectorFormat(
            layer,
            output_path,
            "UTF-8",
            driverName="ESRI Shapefile",
            onlySelected=True
        )
        layer.removeSelection()
        print(f"Created shapefile: {output_path}")
    else:
        print(f"No matching features for expression: {expression}. Skipping shapefile creation for {output_path}")
 
def process_shapefiles(lines_path, points_path):
    """
    Process LINES and POINTS shapefiles to create various output shapefiles.
    Args:
        lines_path (str): The path to the LINES shapefile.
        points_path (str): The path to the POINTS shapefile.
    """
    lines_layer = load_shapefile(lines_path)
    points_layer = load_shapefile(points_path)
 
    if not lines_layer or not points_layer:
        print("Failed to load one or both shapefiles.")
        return
 
    output_folder = os.path.join(os.path.dirname(lines_path), "BOM_EXTRACT")
    os.makedirs(output_folder, exist_ok=True)
 
    tasks = [
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-DUCT\'', "output": "T-CABL-FIBR-DUCT.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-AERL-PIGTAIL\'', "output": "T-CABL-FIBR-AERL-PIGTAIL.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-AERL-BACKBONE\'', "output": "T-CABL-FIBR-AERL-BACKBONE.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-AERL-DIST\'', "output": "T-CABL-FIBR-AERL-DIST.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-AERL-FEED-DIST\'', "output": "T-CABL-FIBR-AERL-FEED-DIST.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-STRAND-6M\'', "output": "T-CABL-FIBR-STRAND-6M.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-STRAND-10M\'', "output": "T-CABL-FIBR-STRAND-10M.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-STRAND-EXST\'', "output": "T-CABL-FIBR-STRAND-EXST.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-UNDR-DROP\'', "output": "T-CABL-FIBR-UNDR-DROP.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-UNDR-BACKBONE\'', "output": "T-CABL-FIBR-UNDR-BACKBONE.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-UNDR-DIST\'', "output": "T-CABL-FIBR-UNDR-DIST.shp"},
        {"layer": lines_layer, "expression": '"LAYER" = \'T-CABL-FIBR-UNDR-FEED-DIST\'', "output": "T-CABL-FIBR-UNDR-FEED-DIST.shp"},
        {"layer": points_layer, "expression": '"LAYER" = \'T-CABL-EQPM-MPT\'', "output": "T-CABL-EQPM-MPT.shp"},
        {"layer": points_layer, "expression": '"LAYER" = \'T-CABL-EQPM-SPLICE_CLOSURE\'', "output": "T-CABL-EQPM-SPLICE_CLOSURE.shp"},
        {"layer": points_layer, "expression": '"LAYER" = \'T-CABL-EQPM-SPLICE_CLOSURE-MIDSPAN\'', "output": "T-CABL-EQPM-SPLICE_CLOSURE-MIDSPAN.shp"},
        {"layer": points_layer, "expression": '"LAYER" = \'T-CABL-SYMB-POLES\'', "output": "T-CABL-SYMB-POLES.shp"}
    ]
 
    for task in tasks:
        task["output"] = os.path.join(output_folder, task["output"])
        select_and_export(task)
 
    print("All shapefiles have been created in the 'BOM_EXTRACT' folder.")
 
def main():
    """
    Main function to execute the shapefile processing workflow.
    """
    lines_path, _ = QFileDialog.getOpenFileName(
        None, "Select 'LINES' Shapefile", "", "Shapefiles (*.shp)"
    )
    if not lines_path:
        print("No 'LINES' shapefile selected.")
        return
 
    points_path, _ = QFileDialog.getOpenFileName(
        None, "Select 'POINTS' Shapefile", "", "Shapefiles (*.shp)"
    )
    if not points_path:
        print("No 'POINTS' shapefile selected.")
        return
 
    process_shapefiles(lines_path, points_path)
 
main()